==========================================
      STOCK MANAGEMENT SYSTEM
==========================================

Version: 1.0
Release Date: [Current Date]

----------------------------
1. GETTING STARTED
----------------------------

1. Unzip the StockManagement.zip file to any folder
2. Run 'StockManagement.exe'
3. Use the default login credentials:
   - Username: admin
   - Password: admin123

----------------------------
2. KEY FEATURES
----------------------------

- Inventory Management:
  • Add/View Companies
  • Add/View Products
  • Track Stock Levels

- Billing System:
  • Create Customer Invoices
  • Automatic GST Calculation
  • Stock Deduction on Sales

- Reporting:
  • Stock Reports
  • Sales Reports
  • Customer Reports

----------------------------
3. FIRST-TIME SETUP
----------------------------

The application will automatically create:
- Database: 'stock_management.db' (in application folder)
- Log file: 'stock_management.log' (in application folder)

No additional setup is required!

----------------------------
4. DEFAULT CREDENTIALS
----------------------------

Admin Account:
- Username: admin
- Password: admin123

User Accounts:
- Create new users via Admin → User Management

----------------------------
5. SYSTEM REQUIREMENTS
----------------------------

- Windows 7/8/10/11 (64-bit recommended)
- 100 MB Disk Space
- 4 GB RAM minimum

----------------------------
6. TROUBLESHOOTING
----------------------------

Common Issues:
- If application won't start:
  1. Install Microsoft Visual C++ Redistributable:
     https://aka.ms/vs/16/release/vc_redist.x64.exe
  2. Ensure your antivirus isn't blocking the .exe

- Database location:
  C:\Path\To\Your\StockManagement\stock_management.db

- Reset application:
  Delete 'stock_management.db' to start fresh

----------------------------
7. CONTACT SUPPORT
----------------------------

For assistance, contact:
support@yourcompany.com

==========================================
    THANK YOU FOR USING OUR SOFTWARE!
==========================================